package patrol.model;

public class Resident {
	
	private int residentId;
	private String residentUsername;
	private String residentPassword;
	private String residentName;
	private int residentPhoneNum;
	private String residentAddress;
	private String residentEmail;
	
	public int getResidentId() {
		return residentId;
	}
	public void setResidentId(int residentId) {
		this.residentId = residentId;
	}
	public String getResidentUsername() {
		return residentUsername;
	}
	public void setResidentUsername(String residentUsername) {
		this.residentUsername = residentUsername;
	}
	public String getResidentPassword() {
		return residentPassword;
	}
	public void setResidentPassword(String residentPassword) {
		this.residentPassword = residentPassword;
	}
	public String getResidentName() {
		return residentName;
	}
	public void setResidentName(String residentName) {
		this.residentName = residentName;
	}
	public int getResidentPhoneNum() {
		return residentPhoneNum;
	}
	public void setResidentPhoneNum(int residentPhoneNum) {
		this.residentPhoneNum = residentPhoneNum;
	}
	public String getResidentAddress() {
		return residentAddress;
	}
	public void setResidentAddress(String residentAddress) {
		this.residentAddress = residentAddress;
	}
	public String getResidentEmail() {
		return residentEmail;
	}
	public void setResidentEmail(String residentEmail) {
		this.residentEmail = residentEmail;
	}
	
	

}
