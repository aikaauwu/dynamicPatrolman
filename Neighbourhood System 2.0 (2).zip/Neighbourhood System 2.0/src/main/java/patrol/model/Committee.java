package patrol.model;

public class Committee {
	
	private String commId;
	private String commUsername;
	private String commPassword;
	private String commPosition;
	
	
	public String getCommId() {
		return commId;
	}
	public void setCommId(String commId) {
		this.commId = commId;
	}
	public String getCommUsername() {
		return commUsername;
	}
	public void setCommUsername(String commUsername) {
		this.commUsername = commUsername;
	}
	public String getCommPassword() {
		return commPassword;
	}
	public void setCommPassword(String commPassword) {
		this.commPassword = commPassword;
	}
	public String getCommPosition() {
		return commPosition;
	}
	public void setCommPosition(String commPosition) {
		this.commPosition = commPosition;
	}

}
