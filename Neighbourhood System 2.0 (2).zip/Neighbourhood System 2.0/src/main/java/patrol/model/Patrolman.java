package patrol.model;

public class Patrolman {
	
	private String patrolmanId;
	private int residentId;
	private String patrolmanUsername;
	private String patrolmanPassword;
	
	
	public String getPatrolmanId() {
		return patrolmanId;
	}
	public void setPatrolmanId(String patrolmanId) {
		this.patrolmanId = patrolmanId;
	}
	public int getResidentId() {
		return residentId;
	}
	public void setResidentId(int residentId) {
		this.residentId = residentId;
	}
	public String getPatrolmanUsername() {
		return patrolmanUsername;
	}
	public void setPatrolmanUsername(String patrolmanUsername) {
		this.patrolmanUsername = patrolmanUsername;
	}
	public String getPatrolmanPassword() {
		return patrolmanPassword;
	}
	public void setPatrolmanPassword(String patrolmanPassword) {
		this.patrolmanPassword = patrolmanPassword;
	}
	
}
